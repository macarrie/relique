# relique-module-generic
Generic module definition for relique backup system
